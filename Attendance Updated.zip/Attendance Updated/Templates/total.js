<script type="text/javascript" src="view_term_work.php"> 
import{y,result,attend} from './view_term_work.php' 
a=y; b=result; 
c=attend; 
grandtotal=a+b+c; 
export{grandtotal}; 
</script>